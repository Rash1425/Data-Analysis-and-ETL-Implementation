# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 12:30:15 2019

@author: ashis
"""





import pandas as pd
import numpy as np
import matplotlib as plt
import seaborn as sns



def Dataset4Visualize(df):
    df.heroin.unique()
    df['heroin']=df["heroin"].str.replace("Y",'1')
    df.loc[df['heroin'].isnull(),'heroin']=0
    df['heroin'].head()
    
    
    df.cocaine.unique()
    df['cocaine']=df["cocaine"].str.replace("Y",'1')
    df.loc[df['cocaine'].isnull(),'cocaine']=0
    df['cocaine'].head()
    
    df.fentanylanalogue.unique()
    df['fentanylanalogue']=df["fentanylanalogue"].str.replace("Y",'1')
    df.loc[df['fentanylanalogue'].isnull(),'fentanylanalogue']=0
    df['fentanylanalogue'].head()
    
    df.oxycodone.unique()
    df['oxycodone']=df["oxycodone"].str.replace("Y",'1')
    df.loc[df['oxycodone'].isnull(),'oxycodone']=0
    df['oxycodone'].head()
    
    df.oxymorphone.unique()
    df['oxymorphone']=df["oxymorphone"].str.replace("Y",'1')
    df.loc[df['oxymorphone'].isnull(),'oxymorphone']=0
    df['oxymorphone'].head()
    
    df.ethanol.unique()
    df['ethanol']=df["ethanol"].str.replace("Y",'1')
    df.loc[df['ethanol'].isnull(),'ethanol']=0
    df['ethanol'].head()
    
    df.hydrocodone.unique()
    df['hydrocodone']=df['hydrocodone'].str.replace('Y','1')
    df.loc[df['hydrocodone'].isnull(),'hydrocodone']=0
    df['hydrocodone'].head()
    df['hydrocodone']=df['hydrocodone'].astype(int)
    
    df['amphet']=df['amphet'].str.replace('Y','1')
    df.loc[df['amphet'].isnull(),'amphet']=0
    df['amphet'].head()
    df['amphet']=df['amphet'].astype(int)
    
    df['tramad']=df['tramad'].str.replace('Y','1')
    df.loc[df['tramad'].isnull(),'tramad']=0
    df['tramad'].head()
    df['tramad']=df['tramad'].astype(int)
    
    df.anyopioid.unique()
    df['anyopioid']=df["anyopioid"].str.replace("Y",'1')
    df['anyopioid']=df["anyopioid"].str.replace("N",'1')
    df.loc[df['anyopioid'].isnull(),'anyopioid']=0
    df['anyopioid'].head()
    
    
    
    BloodReport = pd.DataFrame(df, columns= ['year', 'heroin','cocaine','ethanol','anyopioid'])
    
    
    pd.pivot_table(BloodReport,index=['year'],aggfunc=np.sum).plot()
    
    drug_type=pd.DataFrame(df,columns=['heroin','cocaine','fentanylanalogue','oxycodone','oxymorphone','ethanol','hydrocodone','methadone','amphet','tramad','anyopioid'])
    
    deaths_by_drug = drug_type.sum().sort_values(ascending=False)
    fig, ax = plt.subplots(1, 1, figsize=[15, 7])
    sns.barplot(x=deaths_by_drug, y=deaths_by_drug.index)
    ax.set_xlabel('Total deaths from 2012 to 2018')
    ax.set_title('Accidental deaths by drug type')
    plt.show()
