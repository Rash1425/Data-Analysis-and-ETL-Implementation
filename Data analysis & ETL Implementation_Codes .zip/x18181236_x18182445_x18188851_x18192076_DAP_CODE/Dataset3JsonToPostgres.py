# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 10:22:41 2019

@author: ashis

"""
import psycopg2
import pymongo
import json
import pandas as pd
def JsonToPostgres(Path):
#########################taking data from json and putting it into postgres##########################################
    dbConnection= psycopg2.connect(
        user = "postgres",
        password = "t1864046",
        host = "127.0.0.1",
        port = "5432",
        database = "postgres")
    
    cursor = dbConnection.cursor()
    dbConnection.set_isolation_level(0) 
    
    
    with open(path, 'r') as f:
        array = json.load(f)
    
    
    array[0]["DOWNLOAD DATE"]
    
    
    mongoclient=pymongo.MongoClient("mongodb://localhost:27017") #to connect to mongodb
    #Creating a Database in mongo
    mydb= mongoclient["DAPCA"]
    mycollection=mydb["conneticut_trials"]
    ###inserting the data in mongo DB
    dictionary={}
    #temp=[]
    j=0
    for i in array:
        temp=[]
        dictionary[j]={}
        temp.append(i['DOWNLOAD DATE'])
        temp.append(i['IDENTIFIER'])
        temp.append(i['LATEST ADMISSION DATE'])
        temp.append(i['RACE'])
        temp.append(i['GENDER'])
        temp.append(i['AGE'])
        temp.append(i['BOND AMOUNT'])
        temp.append(i['OFFENSE'])
        temp.append(i['FACILITY'])
        temp.append(i['DETAINER                                        '])  
        dictionary[j]["data"]=temp
        dictionary[j]["column"]=["DOWNLOAD DATE","IDENTIFIER","LATEST ADMISSION DATE","RACE","GENDER","AGE","BOND AMOUNT","OFFENSE","FACILITY","DETAINER"]
    
        x=mycollection.insert_one(dictionary[j])
        j=j+1
    
    
    data=mydb.conneticut_trials
    data=data.find()
    
    input_string="INSERT into conneticut_trials values ("+"'{}',"*8+"'{}')"
    
    #puting data inside the postgres
    for i in data:
        #print(i["data"])
        string=input_string.format(*i["data"][1:])
        #print(string)
        cursor.execute(string)
        cursor.execute()
    df=pd.read_sql_query("select * from conneticut_trials", con=dbConnection) 
    return df