# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 11:38:25 2019

@author: ashis
"""

import psycopg2
def CSVtoPostgres(file):
    
    ##############downloading csv file from kaggle to local machine################## 
    
    
    #############Creating terrorism database########################################
    try:
        dbConnection = psycopg2.connect(
        user = "postgres", 
        password = "admin123", 
        host = "127.0.0.1",
        port = "5432",
        database = "postgres")
        dbConnection.set_isolation_level(0)  ## for Autocommit
        dbCursor = dbConnection.cursor()
        dbCursor.execute("CREATE DATABASE terrorism;")
        dbCursor.close()
    except (Exception, psycopg2.Error) as dbError :
        print ("Error while connecting to PostgreSQL", dbError)
    finally:
        if(dbConnection):
            dbConnection.close()
    ################################################################################
            
    ##################Creating a table AccidentInCity ##############################
    try:
        dbConnection = psycopg2.connect(
        user = "postgres",
        password = "admin123",
        host = "127.0.0.1",
        port = "5432",
        database = "terrorism")
        dbConnection.set_isolation_level(0)
        dbCursor = dbConnection.cursor()
        dbCursor.execute("""
    CREATE TABLE terrorismInCity(
    eventid	                    TEXT,
    iyear	                    TEXT,
    imonth	                    TEXT,
    iday	                    TEXT,
    approxdate	                TEXT,
    extended	                TEXT,
    resolution	                TEXT,
    country	                    TEXT,
    country_txt	                TEXT,
    region	                    TEXT,
    region_txt	                TEXT,
    provstate	                TEXT,
    city	                    TEXT,
    latitude	                TEXT,
    longitude	                TEXT,
    specificity	                TEXT,
    vicinity	                TEXT,
    location	                TEXT,
    summary	                    TEXT,
    crit1	                    TEXT,
    crit2	                    TEXT,
    crit3	                    TEXT,
    doubtterr	                TEXT,
    alternative	                TEXT,
    alternative_txt	            TEXT,
    multiple	                TEXT,
    success	                    TEXT,
    suicide	                    TEXT,
    attacktype1	                TEXT,
    attacktype1_txt	            TEXT,
    attacktype2	                TEXT,
    attacktype2_txt	            TEXT,
    attacktype3	                TEXT,
    attacktype3_txt	            TEXT,
    targtype1	                TEXT,
    targtype1_txt	            TEXT,
    targsubtype1	            TEXT,
    targsubtype1_txt	        TEXT,
    corp1	                    TEXT,
    target1	                    TEXT,
    natlty1	                    TEXT,
    natlty1_txt	                TEXT,
    targtype2	                TEXT,
    targtype2_txt	            TEXT,
    targsubtype2	            TEXT,
    targsubtype2_txt	        TEXT,
    corp2	                    TEXT,
    target2	                    TEXT,
    natlty2	                    TEXT,
    natlty2_txt	                TEXT,
    targtype3	                TEXT,
    targtype3_txt	            TEXT,
    targsubtype3	            TEXT,
    targsubtype3_txt	        TEXT,
    corp3	                    TEXT,
    target3	                    TEXT,
    natlty3	                    TEXT,
    natlty3_txt	                TEXT,
    gname	                    TEXT,
    gsubname	                TEXT,
    gname2	                    TEXT,
    gsubname2	                TEXT,
    gname3	                    TEXT,
    gsubname3	                TEXT,
    motive	                    TEXT,
    guncertain1	                TEXT,
    guncertain2	                TEXT,
    guncertain3	                TEXT,
    individual	                TEXT,
    nperps	                    TEXT,
    nperpcap	                TEXT,
    claimed	                    TEXT,
    claimmode	                TEXT,
    claimmode_txt	            TEXT,
    claim2	                    TEXT,
    claimmode2	                TEXT,
    claimmode2_txt	            TEXT,
    claim3	                    TEXT,
    claimmode3	                TEXT,
    claimmode3_txt	            TEXT,
    compclaim	                TEXT,
    weaptype1	                TEXT,
    weaptype1_txt	            TEXT,
    weapsubtype1	            TEXT,
    weapsubtype1_txt	        TEXT,
    weaptype2	                TEXT,
    weaptype2_txt	            TEXT,
    weapsubtype2	            TEXT,
    weapsubtype2_txt	        TEXT,
    weaptype3	                TEXT,
    weaptype3_txt	            TEXT,
    weapsubtype3	            TEXT,
    weapsubtype3_txt	        TEXT,
    weaptype4	                TEXT,
    weaptype4_txt	            TEXT,
    weapsubtype4	            TEXT,
    weapsubtype4_txt	        TEXT,
    weapdetail	                TEXT,
    nkill	                    TEXT,
    nkillus	                    TEXT,
    nkillter	                TEXT,
    nwound	                    TEXT,
    nwoundus	                TEXT,
    nwoundte	                TEXT,
    property	                TEXT,
    propextent	                TEXT,
    propextent_txt	            TEXT,
    propvalue	                TEXT,
    propcomment	                TEXT,
    ishostkid	                TEXT,
    nhostkid	                TEXT,
    nhostkidus	                TEXT,
    nhours	                    TEXT,
    ndays	                    TEXT,
    divert	                    TEXT,
    kidhijcountry	            TEXT,
    ransom	                    TEXT,
    ransomamt	                TEXT,
    ransomamtus	                TEXT,
    ransompaid	                TEXT,
    ransompaidus	            TEXT,
    ransomnote	                TEXT,
    hostkidoutcome	            TEXT,
    hostkidoutcome_txt	        TEXT,
    nreleased	                TEXT,
    addnotes	                TEXT,
    scite1	                    TEXT,
    scite2	                    TEXT,
    scite3	                    TEXT,
    dbsource	                TEXT,
    INT_LOG	                    TEXT,
    INT_IDEO	                TEXT,
    INT_MISC	                TEXT,
    INT_ANY	                    TEXT,
    related                     TEXT
    );    
        """)
        dbCursor.close()
    except (Exception, psycopg2.Error) as dbError :
        print ("Error while connecting to PostgreSQL", dbError)
    finally:
        if(dbConnection):
            dbConnection.close()
    ################Creating table ends here####################################
            
            
            
    ##################Inserting the values into postgres############################
    import csv
    try:
        with open(file, 'r') as f:
            reader = csv.reader(f)
            next(reader) #  for skipping the header
            
            for i in reader:
                dbCursor.execute( "INSERT INTO terrorismincity VALUES (%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s, %s,%s, %s, %s,%s, %s, %s, %s)",i)
        dbConnection.commit()
        dbCursor.close()
    except(Exception, psycopg2.Error) as dbError:
        print("Error:", dbError)
    finally:
        if(dbConnection): dbConnection.close()
    
    ######################Insertion of values ends here ############################