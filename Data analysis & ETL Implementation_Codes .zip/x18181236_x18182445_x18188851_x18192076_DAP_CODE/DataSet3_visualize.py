# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 10:29:27 2019

@author: Dharesh

"""


#import csv
import pandas as pd
import plotly.graph_objects as go
from plotly.offline import plot
import matplotlib.pyplot as plt
import seaborn as sns

def DataSet2visualize(df):
###########trials according to gender##########
    gender=df["GENDER"].value_counts()
    
    gender=gender.reset_index()
    
    fig = go.Figure(data=[go.Pie(labels=gender['index'], values=gender['GENDER'])])
    
    plot(fig)
    
    
    
    
    
    df['age']=df['age'].astype('str').astype('int')
    
    
    
    
    
    
    ####################trials on the basis of age########
    #making bins####
    age=pd.cut(df["age"],bins=[0,20,35,55,100],labels=["TEENAGE[0-20]","YOUNG[20-35]","MIDDLE-AGED[35-55]","OLD[55+]"])
     
    age=pd.DataFrame(age)
    age.columns
    
    age["age"].value_counts().plot.pie(autopct = "%1.0f%%",shadow =True,startangle = 0,colors = sns.color_palette("prism",5),
                                                wedgeprops = {"linewidth" :3,"edgecolor":"w"})
    my_circ = plt.Circle((0,0),.7,color = "white")
    plt.gca().add_artist(my_circ)
    plt.ylabel("")
    plt.title("Distribution of age groups of people on trials",fontsize=20)
    plt.show()
    
    
    
    
    
    
    
    
    
    
    #########################trials on the basis of crime#####
    df.columns
    
    df['codes']=df['OFFENSE'].astype(str).str.split().str[-1]
    
    crime=df.codes.value_counts()
    
    crime
    ##########df,M,F, SENT,
    gun=df.loc[df['OFFENSE'].str.contains('GUN')]
    total=[]
    total.append(gun.IDENTIFIER.count())
    terror=df.loc[df['OFFENSE'].str.contains('TERRORISM')]
    total.append(terror.IDENTIFIER.count())
    
    drugs=df.loc[df['OFFENSE'].str.contains('LIQ OR DRUGS')]
    total.append(drugs.IDENTIFIER.count())
    
    sns.barplot(y=total,x=["GUN RELATED CRIME","TERRORSM","INFLUENCE OF DRUGS"],palette="cool",
                linewidth = .5 , edgecolor = "k"*30 )
    
    
    
    
    
    
    
    ############################trial on gun voilence###############################
    
    gun.loc["new"]=pd.to_datetime(gun["LATEST ADMISSION DATE"])
    gun["year"] = gun["date"].dt.year
    gun["quarter"] = gun["date"].dt.quarter
    gun.group_by
    gun_group=gun.groupby(['year','quarter']).count()
    gun_group
    gun_group=gun_group.reset_index()
    
    gun_group.plot.scatter(x=('year','quarter'), y='codes')
    plt.show()
    gun_group.codes.unstack(level=0).plot(kind='bar')
    
    
    gun.columns
    
    
    
    
    
    
    
    
    ##############################trials on terrorist activity####################
    terror["date"]=pd.to_datetime(terror["LATEST ADMISSION DATE"])
    terror["year"] = terror["date"].dt.year
    terror["quarter"] = terror["date"].dt.quarter
    terror_group=terror.groupby(['year','quarter']).count()
    terror_group.codes.unstack(level=0).plot(kind='bar')
    
    
    
    
    
    
    
    
    
    
    
    ############################trials on drug related##################################
    drugs["date"]=pd.to_datetime(drugs["LATEST ADMISSION DATE"])
    drugs["year"] = drugs["date"].dt.year
    drugs["quarter"] = drugs["date"].dt.quarter
    
    drugs_group=drugs[drugs['year']>2015].groupby(['year','quarter']).count()
    drugs_group.codes.unstack(level=0).plot(kind='bar')
    
    drugs_group.codes.unstack(level=0).plot(kind='bar',figsize=(30,30))
    drugs_group
    
    





