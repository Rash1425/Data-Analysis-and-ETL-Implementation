# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 10:15:37 2019

@author: ashis
"""
import xmltodict
import pprint
import json
def xmltojson(xml,json_path):
    with open(xml) as fd:
        doc = xmltodict.parse(fd.read())

        pp = pprint.PrettyPrinter(indent=4)
        js=pp.pprint(json.dumps(doc))
    with open(json_path, 'w') as outfile:
        json.dump(js, outfile)
    return json_path