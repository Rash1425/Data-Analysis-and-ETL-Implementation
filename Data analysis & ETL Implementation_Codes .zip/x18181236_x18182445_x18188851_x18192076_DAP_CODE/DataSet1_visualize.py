# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 09:53:02 2019

@author: ashis
"""
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
import plotly.express as px
from plotly.offline import plot



#
######################changing the datatype#############################
def Dataset1_Vizualize(df):

    df["date"] = pd.to_datetime(df["date_"])
    
    df["day"] = df["date"].dt.day
    df["month"] = df["date"].dt.month
    df["year"] = df["date"].dt.year
    df["weekday"] = df["date"].dt.weekday
    df["week"] = df["date"].dt.week
    df["quarter"] = df["date"].dt.quarter
    df['n_killed']=df['n_killed'].astype(str).astype(int)
    
    
    
    ####################ploting for connecticut######################
    
    
    
    
    
    df.columns
    connecticut=df[df["state_"]=='Connecticut']
    connecticut_group=connecticut[connecticut['year']>2015].groupby(['year','quarter'])["n_killed"].agg('sum')
    
    connecticut_group=pd.DataFrame(connecticut_group)
    connecticut_group.unstack(level=0).plot(kind='bar',figsize=(10,10), title="Cases in Connecticut devided by Quater")
    ###########columns in DataFrame############
    
    
    
    
    
    a=df.columns.values
    
    df.info()
    
    print(df.shape)
    
    
    
    
    #############clearing sources#######################
    
    
    
    
    
    
    df = df.drop(["incident_url","incident_url_fields_missing"],axis=1)
    
    df.sources=df['sources'].str.split("//").str[1].str.split("/").str[0]
    
    df.sources=df["sources"].str.replace("www.|.com|.net|.co|.gov|.org","")
    sources = df[df["sources"].notnull()] 
    
    
    w = WordCloud(background_color="white",colormap="cool",scale=5).generate(" ".join(sources["sources"]))
    
    
    plt.figure(figsize=(14,9))
    plt.imshow(w,interpolation="bilinear")
    plt.imshow(w)
    #plt.axis("off")
    plt.show()
    
    sources_df=sources["sources"].value_counts()
    sources_df=sources_df.reset_index()
    sources_df.columns
    fig = px.bar(sources_df[:20],x="index",y="sources")
    plot(fig)
    
    #######################################
    
    
    
    
    
    
    
    
    df.gun_stolen=df['gun_stolen'].str.replace("Unknown|[0-9]|[|:]|","")
    
    df.gun_type=df["gun_type"].str.replace("Unknown|[0-9]|[|:]|","")
    
    
    ####################whic gun used in voilence######
    
    gun_tp = df[df["gun_type"].notnull()]   
    
    print(gun_tp.gun_type)
    
    
    w = WordCloud(background_color="white",colormap="cool",scale=5).generate(" ".join(gun_tp["gun_type"]))
    
    
    plt.figure(figsize=(14,9))
    plt.imshow(w,interpolation="bilinear")
    plt.imshow(w)
    #plt.axis("off")
    plt.show()
    
    ##########################if the Gun is Stolen in incident #####################
    
    
    
    
    
    
    gun_stl = df[df["gun_stolen"].notnull()] 
    
    w = WordCloud(background_color="white",colormap="cool",scale=5).generate(" ".join(gun_tp["gun_stolen"]))
    
    plt.figure(figsize=(14,9))
    plt.imshow(w,interpolation="bilinear")
    plt.imshow(w)
    #plt.axis("off")
    plt.show()
    
    
    
    
    
    
    ####################################
    df.columns
    ############################location_dexcription###############################
    
    lct_des = df[df["location_description"].notnull()] 
    
    w = WordCloud(background_color="white",colormap="cool",scale=5).generate(" ".join(lct_des["location_description"]))
    
    plt.figure(figsize=(14,9))
    plt.imshow(w,interpolation="bilinear")
    plt.imshow(w)
    #plt.axis("off")
    plt.show()
    
    #####################################location bar plot####################
    
    lct_ds_cnt = df[df['location_description'].notnull()]["location_description"].value_counts()[:30]
    
    lct_ds_cnt = pd.DataFrame(lct_ds_cnt).reset_index()
    plt.figure(figsize=(12,12))
    sns.barplot(y=lct_ds_cnt["index"],x=lct_ds_cnt["location_description"],palette="cool",
                linewidth = .5 , edgecolor = "k"*30 )
    
    ################################ killed per state #########################################
    #################
    df['n_killed']=df['n_killed'].astype(str).astype(int)
    state_killed=df.groupby(['state_'])['n_killed'].agg('sum')
    
    df_stat_kille=pd.DataFrame(state_killed)
    df_stat_kille.columns=['total']
    df_stat_kille['state']=df_stat_kille.index
    
    df_stat_kille['total'].sort_values( ascending=False)
    
    plt.figure(figsize=(15,15))
    sns.barplot(y=df_stat_kille["state"],x=df_stat_kille["total"],palette="cool",
                linewidth = .5 , edgecolor = "k"*30 )
    
    import squarify
    plt.figure(figsize=(20,20))
    
    squarify.plot(df_stat_kille["total"],label=df_stat_kille["state"],color=sns.color_palette("magma"),alpha=.7,linewidth=2,edgecolor="b")
    plt.title(" number of people killed in all states")
    plt.axis("off")
    plt.show()
    #############################################################################
    a=df.groupby(['year'])['n_killed'].agg('sum')
    sum_by_year=pd.DataFrame(a)
    sum_by_year.columns=["Values"]
    sum_by_year["year"]=sum_by_year.index
    fig = px.bar(sum_by_year,x="year",y="Values")
    plot(fig)
    
    
    
    
    
    
    
    
    
    ###########################distributing on the basis of age#######################################################
    age_ = df[df["participant_age"].notnull()][["participant_age"]]
    age_["participant_age"] = age_["participant_age"].str.replace("::","-")
    age_["participant_age"] = age_["participant_age"].str.replace(":","-")
    age_["participant_age"] = age_["participant_age"].str.replace("[||]",",")
    age_ = pd.DataFrame(age_["participant_age"])
    age_.head(5)
    x10 = pd.DataFrame(age_["participant_age"].str.split(",").str[0])
    x20 = pd.DataFrame(age_["participant_age"].str.split(",").str[1])
    x30 = pd.DataFrame(age_["participant_age"].str.split(",").str[2])
    x40 = pd.DataFrame(age_["participant_age"].str.split(",").str[3])
    x50 = pd.DataFrame(age_["participant_age"].str.split(",").str[4])
    x60 = pd.DataFrame(age_["participant_age"].str.split(",").str[5])
    x70 = pd.DataFrame(age_["participant_age"].str.split(",").str[6])
    x10 = x10[x10["participant_age"].notnull()]
    x20 = x20[x20["participant_age"].notnull()]
    x30 = x30[x30["participant_age"].notnull()]
    x40 = x40[x40["participant_age"].notnull()]
    x50 = x50[x50["participant_age"].notnull()]
    x60 = x60[x60["participant_age"].notnull()]
    x70 = x70[x70["participant_age"].notnull()]
    
    age_dec1  = pd.concat([x10,x20,x30,x40,x50,x60,x70],axis = 0)
    
    
    age_dec1["lowr_lmt"] = age_dec1["participant_age"].str.split("-").str[0]
    age_dec1["uppr_lmt"] = age_dec1["participant_age"].str.split("-").str[1]
    age_dec1.head()
    
    age_dec1= age_dec1[age_dec1["lowr_lmt"]!='']
    age_dec1["lowr_lmt"] = age_dec1["lowr_lmt"].astype(int)
    age_dec1["uppr_lmt"] = age_dec1["uppr_lmt"].astype(int)
    
    age_dec1.head(10)
    
    age_dec1["age_bin"] = pd.cut(age_dec1["uppr_lmt"],bins=[0,20,35,55,130],labels=["TEENAGE[0-20]","YOUNG[20-35]","MIDDLE-AGED[35-55]","OLD[>55]"])
    plt.figure(figsize=(8,8))
    age_dec1["age_bin"].value_counts().plot.pie(autopct = "%1.0f%%",shadow =True,startangle = 0,colors = sns.color_palette("prism",5),
                                                wedgeprops = {"linewidth" :3,"edgecolor":"w"})
    my_circ = plt.Circle((0,0),.7,color = "white")
    plt.gca().add_artist(my_circ)
    plt.ylabel("")
    plt.title("Distribution of age groups of participants",fontsize=20)
    plt.show()
    #########################################################################
    
    
    
    
    
    
    
    
    #############################distributing on the basis of gender####
    
    gender1 = df["participant_gender"].str.replace("[::0-9|]","").str.upper()
    gender1 = gender1.str.replace("FEMALE","F")
    gender1 = gender1.str.replace("MALE","M")
    gender1 = pd.DataFrame(gender1)
    gender1 = gender1[gender1["participant_gender"].notnull()]
    gender1["female"] = gender1["participant_gender"].str.count("F")
    gender1["male"]   = gender1["participant_gender"].str.count("M")
    size = [sum(gender1["female"]),sum(gender1["male"])]
    plt.figure(figsize=(8,8))
    plt.pie(size,labels=["FEMALE","MALE"],shadow=True,autopct="%1.0f%%",wedgeprops={"linewidth":2,"edgecolor":"k"},explode=[.1,0])
    plt.title("GENDER PROPORTION BY PARTICIPANTS")
    plt.show()
    
    ###############################################################
    
    
    
    
    #####################generating inference from notes#############
    
    from wordcloud import STOPWORDS
    
    notes = df[df["notes"].notnull()]["notes"]
    
    wc3 = WordCloud(stopwords=STOPWORDS,scale=5,background_color="black",colormap="cool").generate(str(notes))
    plt.figure(figsize=(15,10))
    plt.imshow(wc3,interpolation="bilinear")
    plt.axis("off")
    plt.show()
    
    
    ##########################################################
    
    
    
    
    
    
        
    
    
    
    #######################checking by year##############
    
    total_states=df[df['year']<2018 ].groupby(['year'])['n_killed'].agg('sum')
    
    total_states=pd.DataFrame(total_states)
    total_states.unstack(level=0).plot(kind='bar',figsize=(10,10), title="Cases in USA devided by year")