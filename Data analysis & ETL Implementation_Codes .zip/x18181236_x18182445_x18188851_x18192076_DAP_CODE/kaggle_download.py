
import kaggle as kg
import os

def kaggle_download(username,kaggle_key,dataset,path):
    os.environ['KAGGLE_USERNAME'] = username
    os.environ['KAGGLE_KEY'] = kaggle_key
#os.environ['KAGGLE_PROXY'] = '<proxy-address>' 
    kg.api.authenticate()
    kg.api.dataset_download_files(dataset=dataset, path=path, unzip=True)



