# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 10:07:26 2019

@author: ashis
"""

import pandas as pda
#import re
def csvtoxml(csvfile, path):
    csv_filename = csvfile
    
    def load_data(file_path):
        return pda.read_csv(file_path)
        
    def csvtoxml_conversion(dataset,filename,new_filepath):
        xml_filename = filename.split(sep='.')[0]+".xml"
        print(xml_filename)
        with open(new_filepath+xml_filename,'w+',encoding='utf-8') as f:
            #f.write('<?xml version="1.0" encoding="UTF-8" standalone="no"?>' + "\n")
            for index,line in dataset.iterrows():
                row = line.values
                f.write('<case>'+"\n")
                for i in range(len(tags)):
                    val = str(row[i]).replace("!@#$%^&*()[]{}<>?`~-", " ")
                    f.write("\t" + '<' + tags[i] + '>' + val + '</' + tags[i] + '>' + "\n")
                f.write('</case>' + "\n") 
                
    #function call to load dataset
    dataset = load_data(csv_filename)
    
    #extracting dataset headers
    tags = list(dataset.columns.values)
    tags = [tag.replace(' ','_') for tag in tags]
    
    #function call to convert csv file to xml               
    csvtoxml_conversion(dataset,csv_filename,path)
    return xml_filename