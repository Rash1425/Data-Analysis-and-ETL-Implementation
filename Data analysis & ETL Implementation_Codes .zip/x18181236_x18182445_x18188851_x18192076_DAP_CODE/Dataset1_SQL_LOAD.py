# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 09:30:21 2019

@author: ashis
"""
import psycopg2
import pandas as pd
#########################################creating Database connection#################


def postgres():
    dbConnection= psycopg2.connect(
    user = "postgres",
    password = "t1864046",
    host = "127.0.0.1",
    port = "5432",
    database = "postgres")
    cursor = dbConnection.cursor()
    dbConnection.set_isolation_level(0)

    try:
        cursor.execute("""create table GUN_DEATH
						(
							incident_id  		TEXT,
							date_  				Text,
							state_ 				TEXT ,
							city_or_county 		TEXT ,
							address				TEXT,
							n_killed 				 Text,
							n_injured 			 TEXT ,
							congressional_district	TEXT,
							gun_stolen    	TEXT,
							gun_type      TEXT,
							incident_characteristics TEXT,
							latitude TEXT,
							location_description TEXT,
							longitude	TEXT,
							n_guns_involved	TEXT,
							participant_age	 TEXT,
							participant_age_group  TEXT,
							participant_gender	TEXT,
							participant_name   TEXT,
							participant_relationship TEXT,
							participant_status TEXT,
							participant_type TEXT,
							sources  TEXT,
							state_house_district   TEXT,
							state_senate_district  TEXT
						);""")
		
    except (Exception ) as dbError :
            ("Error while connecting to PostgreSQL", dbError)
    finally:
        print (dbConnection.get_dsn_parameters(),"\n")
        if(dbConnection): 
            dbConnection.close()
            print ("done")
		
	##########################inserting data in table ################################
	
	
	#import pandas as pd
    input_string="INSERT into GUN_DEATH_US values ("+"'{}',"*28+"'{}')"
    print(input_string)
    dbConnection = psycopg2.connect(
		user = "postgres",
		password = "t1864046",
		host = "127.0.0.1",
		port = "5432",
		database = "postgres")
	
    try:
        file="C:\\Users\\Public\\Documents\\data.zip\\gun-violence-data_01-2013_03-2018.csv"
        dbConnection.set_isolation_level(0)
        cursor = dbConnection.cursor()
		#print(cursor.execute("select count(*) from gun_death_us;"))
        with open(file, 'r',encoding='utf-8-sig') as f:
            reader = csv.reader(f)
            next(reader) # skip the header
            cursor = dbConnection.cursor()
            for row in reader:
                new=row[0:7]+row[10:18]+row[19:]
				#print(str(new)[1:-1])
				#new1=re.sub("\w\'\w",'',str(new)[1:-1])
                item="INSERT INTO GUN_DEATH VALUES ({})".format(str(new)[1:-1])
				#print(input_string.format(*row))
				#break
                cursor.execute(item)
		#df=pd.read_csv(file)
		
		
        
    except (Exception , psycopg2.Error) as dbError :
        print ("Error while connecting to PostgreSQL", dbError)
    finally:
		#print (dbConnection.get_dsn_parameters(),"\n")
        if(dbConnection): 
            dbConnection.close()
            print ("done")
			
		
		
		
		
		
		
	
	
	##############updating the table and reading from database #####################
    cursor.execute("UPDATE gun_death  SET participant_relationship = NULL WHERE participant_relationship = ''")
    cursor.execute("UPDATE gun_death  SET congressional_district = NULL WHERE congressional_district = ''")
    cursor.execute("UPDATE gun_death  SET gun_type = NULL WHERE gun_type = ''")
    cursor.execute("UPDATE gun_death  SET latitude = NULL WHERE latitude = ''")
    cursor.execute("UPDATE gun_death  SET location_description = NULL WHERE location_description = ''")
    cursor.execute("UPDATE gun_death  SET longitude = NULL WHERE longitude = ''")
    cursor.execute("UPDATE gun_death  SET n_guns_involved = NULL WHERE n_guns_involved = ''")
	#cursor.execute("UPDATE gun_death  SET participant_relationship = NULL WHERE notes = ''")
    cursor.execute("UPDATE gun_death  SET participant_age = NULL WHERE participant_age = ''")
    cursor.execute("UPDATE gun_death  SET participant_age_group = NULL WHERE participant_age_group = ''")
    cursor.execute("UPDATE gun_death  SET participant_gender = NULL WHERE participant_gender = ''")
    cursor.execute("UPDATE gun_death  SET participant_name = NULL WHERE participant_name = ''")
    cursor.execute("UPDATE gun_death  SET participant_status = NULL WHERE participant_status = ''")
    cursor.execute("UPDATE gun_death  SET participant_type = NULL WHERE participant_type = ''")
    cursor.execute("UPDATE gun_death  SET sources = NULL WHERE sources = ''")
    cursor.execute("UPDATE gun_death  SET state_house_district = NULL WHERE state_house_district = ''")
    cursor.execute("UPDATE gun_death  SET state_senate_district = NULL WHERE state_senate_district = ''")
    cursor.execute("UPDATE gun_death  SET address = NULL WHERE address = ''")
	
    df = pd.read_sql_query('select * from gun_death',con=dbConnection)
    return (df)
	