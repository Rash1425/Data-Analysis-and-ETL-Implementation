# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 11:14:46 2019

@author: ashis
"""
import psycopg2
import pymongo
import pandas as pd
def MongotoPostgres():
    try:
        mongoclient=pymongo.MongoClient("mongodb://localhost:27017") #to connect to mongodb
    #Creating a Database in mongo
        mydb= mongoclient["DAPdb"]
        mycollection=mydb["Accident_by_Drugs"]
        dbConnection = psycopg2.connect(
        user = "postgres",
        password = "Rash#25",
        host = "127.0.0.1",
        port = "5432",
        database = "death_drugs")
        dbConnection.set_isolation_level(0)
        dbCursor = dbConnection.cursor()
        dbCursor.execute("""
    CREATE TABLE AccidentInCity(
    ID TEXT ,
    Date TEXT,
    DateType TEXT,
    Age TEXT,
    Sex TEXT,
    Race TEXT,
    ResidenceCity TEXT,
    ResidenceCounty TEXT,
    ResidenceState TEXT,
    DeathCity TEXT,
    DeathCounty TEXT,
    Location TEXT,
    LocationifOther TEXT,
    DescriptionofInjury TEXT,
    InjuryPlace TEXT,
    InjuryCity TEXT,
    InjuryCounty TEXT ,
    InjuryState TEXT,
    COD TEXT,
    OtherSignifican TEXT,
    Heroin TEXT,
    Cocaine TEXT,
    Fentanyl TEXT,
    FentanylAnalogue TEXT,
    Oxycodone TEXT,
    Oxymorphone TEXT,
    Ethanol TEXT,
    Hydrocodone TEXT,
    Benzodiazepine TEXT,
    Methadone TEXT,
    Amphet TEXT,
    Tramad TEXT,
    Morphine_NotHeroin TEXT,
    Hydromorphone TEXT,
    Other TEXT,
    OpiateNOS TEXT,
    AnyOpioid TEXT,
    MannerofDeath TEXT
    );    
        """)
        dbCursor.close()
    except (Exception, psycopg2.Error) as dbError :
        print ("Error while connecting to PostgreSQL", dbError)
    finally:
        if(dbConnection):
            dbConnection.close()
            
            
    try:
        dbConnection = psycopg2.connect(
        user = "postgres", #dap
        password = "Rash#25", #dap
        host = "127.0.0.1", #192.168.56.30
        port = "5432",
        database = "death_drugs")
        dbConnection.set_isolation_level(0) # AUTOCOMMIT
        dbCursor = dbConnection.cursor()
        data=mydb.Accident_by_Drugs
        dictionary=data
        for i in dictionary:
            
            if (dictionary[i]['data'][20]!= None):
                b=dictionary[i]['data'][20]
                c=b.replace("'", "")
                dictionary[i]['data'][20]=c
            if(dictionary[i]['data'][21]!= None):
                b=dictionary[i]['data'][21]
                c=b.replace("'", "")
                dictionary[i]['data'][21]=c
            if(dictionary[i]['data'][22]!= None):
                b=dictionary[i]['data'][22]
                c=b.replace("'", "")
                dictionary[i]['data'][22]=c
            
            insertString = "INSERT INTO accidentInCity VALUES ('{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}','{}')"
            insertRow=insertString.format(*dictionary[i]['data'][8:-4])
            print(insertRow)
            dbCursor.execute(insertRow)
        dbConnection.commit()
        dbCursor.close()
    except(Exception, psycopg2.Error) as dbError:
        print("Error:", dbError)
    finally:
        if(dbConnection): dbConnection.close()
        
    df = pd.read_sql_query('select * from accidentincity',con=dbConnection)
    return df
