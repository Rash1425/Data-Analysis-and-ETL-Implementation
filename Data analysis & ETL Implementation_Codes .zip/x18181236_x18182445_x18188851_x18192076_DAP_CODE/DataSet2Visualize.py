# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 11:59:16 2019

@author: ashis
"""
import psycopg2
import seaborn as sns
import iplot
#####################Updating the blank Value to Null in postgres##############
    
    
########################Loading the required records into the datafarme ########
import pandas as pd
def Visualize():
    try:
        dbConnection = psycopg2.connect(
        user = "postgres",
        password = "admin123",
        host = "127.0.0.1",
        port = "5432",
        database = "terrorism")
        dbConnection.set_isolation_level(0)
        cursor = dbConnection.cursor()
        
        cursor.execute("select * from terrorismincity where country_txt='United States' ")
        a=cursor.fetchall()
        df = pd.DataFrame(a)
                
    except (Exception , psycopg2.Error) as dbError :
        print ("Error while connecting to PostgreSQL", dbError)
    finally:
        
        if(dbConnection): dbConnection.close()
        print ("done")
    ########################Datafarme load ends here#################################
        
        
    ###############Checking the dimension of the dataframe and adding columns ######
    df.shape
    df.head(5)
    df.columns=['eventid','iyear','imonth','iday','approxdate','extended','resolution','country','country_txt','region','region_txt','provstate','city','latitude','longitude','specificity','vicinity','location','summary','crit1','crit2','crit3','doubtterr','alternative','alternative_txt','multiple','success','suicide','attacktype1','attacktype1_txt','attacktype2','attacktype2_txt','attacktype3','attacktype3_txt','targtype1','targtype1_txt','targsubtype1','targsubtype1_txt','corp1','target1','natlty1','natlty1_txt','targtype2','targtype2_txt','targsubtype2','targsubtype2_txt','corp2','target2','natlty2','natlty2_txt','targtype3','targtype3_txt','targsubtype3','targsubtype3_txt','corp3','target3','natlty3','natlty3_txt','gname','gsubname','gname2','gsubname2','gname3','gsubname3','motive','guncertain1','guncertain2','guncertain3','individual','nperps','nperpcap','claimed','claimmode','claimmode_txt','claim2','claimmode2','claimmode2_txt','claim3','claimmode3','claimmode3_txt','compclaim','weaptype1','weaptype1_txt','weapsubtype1','weapsubtype1_txt','weaptype2','weaptype2_txt','weapsubtype2','weapsubtype2_txt','weaptype3','weaptype3_txt','weapsubtype3','weapsubtype3_txt','weaptype4','weaptype4_txt','weapsubtype4','weapsubtype4_txt','weapdetail','nkill','nkillus','nkillter','nwound','nwoundus','nwoundte','property','propextent','propextent_txt','propvalue','propcomment','ishostkid','nhostkid','nhostkidus','nhours','ndays','divert','kidhijcountry','ransom','ransomamt','ransomamtus','ransompaid','ransompaidus','ransomnote','hostkidoutcome','hostkidoutcome_txt','nreleased','addnotes','scite1','scite2','scite3','dbsource','INT_LOG','INT_IDEO','INT_MISC','INT_ANY','related']
    df.head(3)
    df.count
    ###############Column addition ends here#########################################
    
    
    ########################Plotting a heatmap for cheking the not null values######
    
    sns.heatmap(df.isnull(), cbar=False)
    #############################Heatmap Plotting ends here#########################
    
    
    ######################Renamimng the columns properly############################
    ##df.columns.values.tolist()
    df=df.rename(columns={'eventid':'id', 'iyear':'year', 'imonth':'month', 'iday':'day','country_txt':'country1', 'provstate':'state', 'targtype1_txt':'target','weaptype1_txt':'weapon', 'nkill':'fatalities', 'nwound':'injuries'})
    ##df.columns.values.tolist()
    #####################Renaming of columns ends here##############################
    
    ########################Sorting the values as per fatalities and injuries#######
    df = df.sort_values(['fatalities', 'injuries'], ascending = False)
    #######################Sorting ends here########################################
    
    
    #######################Droping the duplicate values ############################
    df = df.drop_duplicates(['date', 'latitude', 'longitude', 'fatalities'])
    #######################Dropping ens here########################################
    
    ######################Setting the variables for plotting#######################
    fatality = dict(
               type = 'scattergeo',
               locationmode = 'USA-states',
               lon = df[df.fatalities > 0]['longitude'],
               lat = df[df.fatalities > 0]['latitude'],
               text = df[df.fatalities > 0]['remarks'],
               mode = 'markers',
               name = 'Fatalities',
               ##hoverinfo = 'text+name',
               marker = dict(
                   size = df[df.fatalities > 0]['fatalities'] ** 0.255 * 8,
                   opacity = 0.95,
                   color = 'rgb(240, 140, 45)')
               )
    
    injury = dict(type = 'scattergeo',locationmode = 'USA-states',
             lon = df[df.fatalities == 0]['longitude'],
             lat = df[df.fatalities == 0]['latitude'],
             text = df[df.fatalities == 0]['remarks'],
             mode = 'markers',
             name = 'Injuries',
             ##hoverinfo = 'text+name',
             marker = dict(
                 size = (df[df.fatalities == 0]['injuries'] + 1) ** 0.245 * 8,
                 opacity = 0.85,
                 color = 'rgb(20, 150, 187)')
             )
    layout = dict(
             title = 'Terrorist Attacks  in United States from 1970 to 2015',
             showlegend = True,
             legend = dict(
                 x = 0.85, y = 0.4
             ),
             geo = dict(
                 scope = 'usa',
                 projection = dict(type = 'albers usa'),
                 showland = True,
                 landcolor = 'rgb(250, 250, 250)',
                 subunitwidth = 1,
                 subunitcolor = 'rgb(217, 217, 217)',
                 countrywidth = 1,
                 countrycolor = 'rgb(217, 217, 217)',
                 showlakes = True,
                 lakecolor = 'rgb(255, 255, 255)')
             )
    ######################Variable ends here########################################
    data = [fatality, injury]
    figure = dict(data = data, layout = layout)
    iplot(figure)
    ##############
 
    
    #####################Plotting Graphs############################################
    df['fatalities']=df['fatalities'].astype('str').astype('int')
    df['year']=df['year'].astype('str')
    df1=df.groupby('year')['fatalities'].agg('sum')
    df1=pd.DataFrame(df1)
    df1.plot(title="Fatalities occured since 1970")##plotting the fatalities over the year
    
    
    df2=df.groupby('year')['injuries'].agg('sum')
    df2=pd.DataFrame(df2)
    df2.plot(title='Injuries occured Since 1970')##Plotting the injuries over the year
    
    
    df3=df.groupby('year')['year'].count()
    df3=pd.DataFrame(df3)
    df3.plot(title="Number of terrorist activity observed per year")##Plotting terrorst attacks per year
    
    
    df_connecticut=df[df['state']=='Connecticut']
    df_connecticut=df_connecticut.groupby('year')['year'].count()
    df_connecticut=pd.DataFrame(df_connecticut)
    df_connecticut.plot(title="Number of terrorist activity observed in connecticut per year")##Plotting number of terrorist attacks in connecticut
    #####################Plotting ends here##########################################


