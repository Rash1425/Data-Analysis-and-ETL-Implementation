# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 12:42:17 2019

@author: ashis
"""
import os 
os.chdir("C:\\Users\\ashis\\Documents\\Python Scripts\\DAP")
os.listdir()
import Dataset1_SQL_LOAD
import DataSet1_visualize
import DataSet2CSVtoPostgres
import DataSet2Visualize
import Dataset3fileload
import DataSet3FileloadJason
import Dataset3JsonToPostgres
import DataSet3_visualize
import DataSet4JsontoMongo
import DataSet4MongoToPstgres
import Dataset4visualize
import kaggle_download

os.environ['KAGGLE_USERNAME'] = 'ashish044'
os.environ['KAGGLE_KEY'] = 'ea962aa9d7c74136761277647b20ca5a'

###############running and visualizing the dataset1############################
##################loading the file in local##########
path='C:\\Users\\Public\\Documents\\data'
kaggle_download('ashish044','ea962aa9d7c74136761277647b20ca5a',"jameslko/gun-violence-data",path)

#################Moving the file from CSV to Postgres ###############
df=Dataset1_SQL_LOAD.postgres()

####################Creating visualizations and Graph##################
DataSet1_visualize.Dataset1_Vizualize(df)







#######################Dataset 2########################


##################downloading from kaggle#############
kaggle_download('ashish044','ea962aa9d7c74136761277647b20ca5a',"START-UMD/gtd",path)


################Moving the file from CSV to Postgres##################
df=DataSet2CSVtoPostgres.CSVtoPostgres(path)

########################Satrting with visualization################

DataSet2Visualize.Visualize(df)


##################################################################










###########################Dataset3################################
##############downloading the file from kaggle########################
kaggle_download('ashish044','ea962aa9d7c74136761277647b20ca5a',"Connecticut-open-data/connecticut-inmates-awaiting-trial",path)

##################converting file from csv to XML################

xml_file_name=Dataset3fileload.csvtoxml("Accused_Pre-Trial_Inmates_in_Correctional_Facilities.csv",path)

###########################converting XML file to Json file###########################
json_path=DataSet3FileloadJason(path+xml_file_name)

#############################from json file loading in MONGO DB then from there Postgres
df=Dataset3JsonToPostgres(json_path)

#################################Visualization for DataSet3 ############################
DataSet3_visualize(df)










##################################DataSet 4############################################

url="https://data.ct.gov/api/views/rybz-nyjw/rows.json?accessType=DOWNLOAD"

DataSet4JsontoMongo.load(url)

DataSet4MongoToPstgres.MongotoPostgres()

df=DataSet4MongoToPstgres.MongotoPostgres()

Dataset4visualize(df)

