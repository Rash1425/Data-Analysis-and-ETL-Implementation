# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 11:10:10 2019

@author: ashis
"""

import requests
import pymongo

def load(url):
    mongoclient=pymongo.MongoClient("mongodb://localhost:27017") #to connect to mongodb
    #Creating a Database in mongo
    mydb= mongoclient["DAPdb"]
    mycollection=mydb["Accident_by_Drugs"]
    
    response=requests.get(url)
    #print(response)
    filecontent=response.json()
    print(filecontent)
    
    url="https://data.ct.gov/api/views/rybz-nyjw/rows.json?accessType=DOWNLOAD"
    response=requests.get(url)
    #print(response)
    filecontent=response.json()
    #filecontent
    
    dictionary={}
    for keys,values in enumerate (filecontent["data"]):
        dictionary[keys]={}
        dictionary[keys]["data"]=values
        dictionary[keys]["type"]="data"
        x=mycollection.insert_one(dictionary[keys])

